package projeto_integrador.estacionamento.DTO;

import lombok.Data;

@Data
public class VeiculoCadastroDTO {
    private String categoria;
    private String placa;
    private String montadora;
    private String modelo;
}
