package projeto_integrador.estacionamento.enuns;

public enum ReservaStatus {
    PENDENTE,
    CONFIRMADO,
    CANCELADO,
    CONCLUIDO
}
