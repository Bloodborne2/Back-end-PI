package projeto_integrador.estacionamento.enuns;

public enum VagaStatus {
    LIVRE,
    RESERVADA,
    OCUPADA,
    INATIVA
}
